

<?php $__env->startSection('main'); ?>    
<body>
    <h1><?php echo e($username); ?> vai Apni Home e Chole Ascen</h1>

    <a href="<?php echo e(route('create')); ?>">Create New Employee</a>
    

</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\blog\resources\views/home.blade.php ENDPATH**/ ?>