

<?php $__env->startSection('main'); ?>   
<body>

	<form method="post" enctype="multipart/form-data">
		
		
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		<fieldset>
			<legend>Create</legend>
		<table>
			<tr>
				<td>Name</td>
				<td><input type="text" name="name" value='<?php echo e(old("name")); ?>'></td>
			</tr>
			<tr>
				<td>Company Name</td>
				<td><input type="text" name="comName" value='<?php echo e(old("comName")); ?>'></td>
			</tr>
            <tr>
				<td>Contact</td>
				<td><input type="text" name="contact" value='<?php echo e(old("contact")); ?>'></td>
			</tr>
			<tr>
				<td>User Name</td>
				<td><input type="text" name="userName" value='<?php echo e(old("userName")); ?>'></td>
			</tr>
			v
			<tr>
				<td>password</td>
				<td><input type="text" name="password"></td>
			</tr>
			<tr>
				<td><input type="submit" name="submit" value="Submit"></td>
			</tr>
		</table>
		</fieldset>
	</form>

    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($err); ?><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\blog\resources\views/create.blade.php ENDPATH**/ ?>